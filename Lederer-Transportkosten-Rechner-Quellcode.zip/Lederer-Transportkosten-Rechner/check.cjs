const assert=require('node:assert/strict');
const d=require('./dist/data.json'),e=require('./dist/engine.js');
const israel=e.calculate(d,{mode:'Export',country:'Israel',weight:115,region:null});
assert.equal(israel.find(r=>r.name==='UPS Express Saver').price,1029.08);
assert.equal(israel.find(r=>r.name==='UPS Express').price,1130.13);
assert.equal(e.autoRegion(d.regions.Export.Deutschland,'Deutschland','58095').zone,'A');
assert.equal(e.autoRegion(d.regions.Export.Deutschland,'Deutschland','01067').zone,'I');
assert.equal(e.autoRegion(d.regions.Export.Frankreich,'Frankreich','75001').zone,'1');
assert.equal(e.autoRegion(d.regions.Export.Frankreich,'Frankreich','invalid'),null);
assert.equal(e.autoRegion(d.regions.Export.Irland,'Irland','Dublin').zone,'1');
const base=e.lookup(d,'Export Saver','11',70).price;
assert.equal(e.split(d,'Export Saver','11',70,70).price,base);
assert.equal(e.split(d,'Export Saver','11',140,70).price,base*2);
assert.equal(e.split(d,'Export Saver','11',71,70).price,base+e.lookup(d,'Export Saver','11',1).price);
assert.throws(()=>e.calculate(d,{mode:'Export',country:'Deutschland',weight:0,region:null}));
assert.equal(e.calculate(d,{mode:'Export',country:'Deutschland',weight:3001,region:d.regions.Export.Deutschland[0]}).find(r=>r.name==='Spedition Schmidt').price,null);
assert.equal(e.calculate(d,{mode:'Import',country:'Deutschland',weight:71,region:null}).find(r=>r.name==='UPS Standard Single').price,null);
let total=0;
for(const mode of ['Export','Import'])for(const country of d.countries)for(const weight of [.5,1,20,30,70,71,100,115,140,200,3000,5001]){
 const regs=d.regions[mode][country]||[];const region=regs[0]||null;
 for(const r of e.calculate(d,{mode,country,weight,region})){
  if(r.price!==null){assert(Number.isFinite(r.price)&&r.price>0,`${mode} ${country} ${weight}: ${r.name}`);assert(Number.isFinite(r.base)&&r.base>0);total++;}
 }
}
console.log(`Passed: Excel reference values, postal mapping, weight boundaries, missing tariffs; ${total} calculated offers checked.`);
