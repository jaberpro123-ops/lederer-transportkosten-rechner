# Lederer Transportkosten Rechner

Vollständiger Quellcode der veröffentlichten Website, Version 3.
Quellstand: 1ecec19bcd32fe60e0734563b8bc818e6226e3e9

## Aufbau

Die Website besteht aus HTML, CSS und JavaScript. Sie braucht keine Datenbank,
kein Framework und keinen Build-Schritt. Die Berechnungen laufen im Browser.

| Datei | Aufgabe |
| --- | --- |
| dist/index.html | Seitenaufbau, Eingabefelder, Länderauswahl und Ergebnisbereich |
| dist/style.css | Layout, Farben, Logos, mobile Darstellung und Druckansicht |
| dist/descriptions.css | Darstellung der Tarifbeschreibungen und Lieferzeiten |
| dist/app.js | Benutzeroberfläche, Dropdowns, Lieferzeittexte und Ergebnisanzeige |
| dist/engine.js | Tarifsuche, Gewichtsstufen, Zuschläge und Preisberechnung |
| dist/data.json | Aus Excel übernommene Tarifdaten, Länder und PLZ-Zonen |
| dist/assets/ | Originalbilder für Lederer, UPS und Schmidt aus der Excel-Datei |
| check.cjs | Prüffälle für Berechnungen, PLZ-Zuordnungen und Gewichtsgrenzen |

## Lokal öffnen

1. ZIP vollständig entpacken.
2. Ein Terminal im entpackten Projektordner öffnen.
3. Mit vorhandenem Python 3 ausführen:

```bash
python -m http.server 8000 --directory dist
```

Auf manchen Systemen lautet der Befehl `python3` statt `python`.
Dann im Browser `http://localhost:8000` öffnen.

Ein Doppelklick auf index.html allein reicht normalerweise nicht, weil der
Browser das Laden von data.json über lokale file-Adressen blockieren kann.

## Auf eigenem Webserver veröffentlichen

Den gesamten Inhalt von dist/ auf einen statischen Webserver kopieren. HTML,
JavaScript, CSS, JSON und Bilder müssen mit ihren relativen Pfaden erreichbar
sein. Es werden kein ChatGPT-Login, keine API-Schlüssel und keine Verbindung
zu ChatGPT für den Betrieb benötigt. Die eigene Domain und HTTPS konfiguriert
der Betreiber des Webservers.

## Berechnungen prüfen

Mit vorhandenem Node.js im Projektordner ausführen:

```bash
node check.cjs
```

Das prüft unter anderem zwei gespeicherte Excel-Vergleichswerte für Israel bei
115 kg, PLZ-Zuordnungen, Gewichtsgrenzen und die Zahlenwerte vieler Angebote.
Diese Prüfungen ersetzen keine vollständige fachliche Freigabe der Tarife.

## Daten und bestehende Einschränkungen

Die Daten stammen aus UPS X Schmidt Tool(1).xlsx und werden nicht automatisch
aktualisiert. Die Original-Excel-Datei ist nicht Teil dieses Codepakets.
Fehlende oder widersprüchliche Zuordnungen werden als nicht verfügbar angezeigt.
Insbesondere wird UPS Standard Multi wegen einer widersprüchlichen Excel-Formel
nicht berechnet; die Export-Standard- und Express-Plus-Berechnung ist auf den im
Code freigegebenen Gewichtsbereich beschränkt. Lieferzeiten sind die Hinweise
aus der Excel-Datei und keine aktuellen Zusagen des Transporteurs.

Die JSON-Tarifdaten sind bei einer öffentlichen Veröffentlichung ebenso
abrufbar wie der übrige Website-Code. Ob die Website öffentlich oder intern
bereitgestellt wird, legt der Betreiber fest.

Die Website-Dateien entsprechen dem bestehenden Quellstand. Diese Anleitung
wurde für die Übergabe ergänzt. Zugangsdaten, Git-Verwaltung und die Konfiguration
des bisherigen Hostingdienstes sind für einen unabhängigen Betrieb nicht nötig
und im Paket nicht enthalten.
